/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import connect.connect_db;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author shilpi
 */
@MultipartConfig
(
        fileSizeThreshold = 1024*1024*2,
        maxFileSize = 1024*1024*10,
        maxRequestSize = 1024*1024*50
)
public class EditAdminProfile extends HttpServlet {

   private final String filePath = "C:\\Users\\shilpi\\Documents\\NetBeansProjects\\Vio Cab\\web\\admin\\images";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            System.out.println("hloooo");
            String Id = request.getParameter("id");
            String Name = request.getParameter("name");
            String Email = request.getParameter("email");
            String Designation = request.getParameter("occupation");
            String PhoneNumber = request.getParameter("phone");
            String Title = request.getParameter("title");
            Part filePart = request.getPart("image");
            System.out.println("full Data is:"+Id+" "+Name+" "+Email+" "+Designation+" "+PhoneNumber+" "+Title);
            String Photo;
            String fileName;
            File file = new File("filePath");
            if(!file.exists()){
                file.mkdir();
            }
            fileName = Title+".jpg";
            try{
                if(filePart.getSize()>0){
                Photo= filePath+File.separator+fileName;
                filePart.write(Photo);
                Connection con = new connect_db().getConnection();
                PreparedStatement ps = con.prepareStatement("update adminlogin set file=? where id=?");
                ps.setString(1, fileName);
                ps.setString(2, Id);
                int i = ps.executeUpdate();
                    if(i>0){
                     out.println("<script type=\"text/javascript\">");
                    out.println("alert(' Successfully Admin Profile Updated')");
                    out.println("window.location.href='admin/dashboard.jsp'");
                    out.println("</script>");
                    }
                     else{
                     out.println("<script type=\"text/javascript\">");
                    out.println("alert(' Admin Profile not Updated')");
                    out.println("window.location.href='admin/edit_profile.jsp'");
                    out.println("</script>");
                    }
                  
            }
                else{
                    Connection conn = new connect_db().getConnection();
                    PreparedStatement ps1 = conn.prepareStatement("update adminlogin set name=?,occupation=?,phone=? where id=?");
                    ps1.setString(1, Name);
                    ps1.setString(2, Designation);
                    ps1.setString(3, PhoneNumber);
            
                    ps1.setString(4, Id);
                    int i= ps1.executeUpdate();
                    if(i>0){
                        out.println("<script type=\"text/javascript\">");
                    out.println("alert(' Successfully Admin Info Updated')");
                    out.println("window.location.href='admin/dashboard.jsp'");
                    out.println("</script>");
                    }
                    else{
                        out.println("<script type=\"text/javascript\">");
                    out.println("alert(' Admin Info not Updated')");
                    out.println("window.location.href='admin/edit_profile.jsp'");
                    out.println("</script>");
                    }
                }
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
