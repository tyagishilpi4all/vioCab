/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import connect.connect_db;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author shilpi
 */
@MultipartConfig
(
        fileSizeThreshold = 1024*1024*2,
        maxFileSize = 1024*1024*10,
        maxRequestSize = 1024*1024*50
)
public class AddServiceDetail extends HttpServlet {

   private final String filePath="C:\\Users\\shilpi\\Documents\\NetBeansProjects\\Vio Cab\\web\\admin\\images";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String Category = request.getParameter("cat_id");
            String SubCategory = request.getParameter("state");
            String ItemName = request.getParameter("itemName");
           String ImageTitle = request.getParameter("imageTitle");
              Part filePart = request.getPart("itemImage");
            String ItemPrice = request.getParameter("itemPrice");
            String Discount = request.getParameter("discount");
            String Discription = request.getParameter("description");
            String Status = request.getParameter("status");
            System.out.println(Category+" "+SubCategory+" "+ItemName+" "+ItemPrice+" "
                    +Discount+" "+Discription+" "+Status);
            String photo;
             String t = ImageTitle+".jpg";
            String fileName;
            File file = new File("filePath");
            if(file.exists()){
                file.mkdir();
            }
            fileName=ImageTitle+".jpg";
            try{
                 Connection con = new connect_db().getConnection();
                PreparedStatement ps = con.prepareStatement("select * from servicedetails where image=?");
                ps.setString(1, t);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    if(rs.getString("img").equals(t)){
                        out.println("<script type=\"text/javascript\">");
                       out.println("alert('Title Matched! Please insert another title')");
                       out.println("window.location.href='admin/view_Item.jsp'");
                       out.println("</script>");
                    }
                }
                    else{
                photo=filePath+File.separator+fileName;
                filePart.write(photo);
                Connection con1 = new connect_db().getConnection();
                PreparedStatement ps1 = con1.prepareStatement("insert into servicedetails(cid,sid,name,image,Price,Discount,Description,status) values(?,?,?,?,?,?,?,?)");
                
                ps1.setString(1, Category);
                ps1.setString(2, SubCategory);
                ps1.setString(3, ItemName);
                ps1.setString(4, fileName);
                ps1.setString(5, ItemPrice);
                ps1.setString(6, Discount);
                ps1.setString(7, Discription);
                ps1.setString(8, Status);
                int i = ps1.executeUpdate();
                System.out.println(ps);
                if(i>0){
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Successfully Service Details Added')");
                    out.println("window.location.href='admin/view_Item.jsp'");
                    out.println("</script>");
                }
                else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Service Details not added')");
                    out.println("window.location.href='admin/Add_Item.jsp'");
                    out.println("</script>");
                }
                } 
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
