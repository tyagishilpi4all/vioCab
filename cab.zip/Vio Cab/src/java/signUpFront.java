/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import connect.connect_db;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author shilpi
 */
@MultipartConfig
(
        fileSizeThreshold = 1024*1024*2,
        maxFileSize = 1024*1024*10,
        maxRequestSize = 1024*1024*50
)
public class signUpFront extends HttpServlet {

  private final String filePath ="C:\\Users\\shilpi\\Documents\\NetBeansProjects\\Vio Cab\\web\\admin\\images";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           String Name = request.getParameter("name");
           String Email = request.getParameter("email");
           String Password = request.getParameter("pass");
           Part filePart = request.getPart("img");
           String Title = request.getParameter("email");
           String Occupation = request.getParameter("occupation");
           String Phone = request.getParameter("phone");
           String Address = request.getParameter("address");
            System.out.println(Name+" "+Email+" "+Password+" "+Title+" "+Occupation+" "+Phone+" "+Address);
            String Photo;
            String fileName;
            
            String subject = "User SignUp";
            File file = new File(filePath);
            if(Title.contains("jpg")){
                fileName=Title;
            }
            else{
               fileName=Title+".jpg";
            }
            int flag=1;
            try{
                System.out.println("hlooo");
               Photo=filePath+File.separator+fileName;
                filePart.write(Photo); 
                Connection con= new connect_db().getConnection();
                PreparedStatement ps= con.prepareStatement("select * from signupfront where email=?");
                ps.setString(1, Email);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    if(rs.getString("email").equals(Email)){
                        flag=0;
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('Already exist')");
                         out.println("window.location.href='login.jsp'");
                         out.println("</script>");
                    }
                }
                else if(flag==1){
                    System.out.println("hlo shilpi");
                    Photo=filePath+File.separator+fileName;
                    filePart.write(Photo);  
                    Connection conn = new connect_db().getConnection();
                    PreparedStatement ps1 = conn.prepareStatement("insert into signupfront(name,email,password,occupation,phone,image,address) values(?,?,?,?,?,?,?)");
                    ps1.setString(1, Name);
                    ps1.setString(2, Email);
                    ps1.setString(3, Password);
                    ps1.setString(4, Occupation);
                    ps1.setString(5, Phone);
                    ps1.setString(6, fileName);
                    ps1.setString(7, Address);
                    int i =ps1.executeUpdate();
                    if(i>0){
                        String MessageBody ="Thank You"+" "+Name+" "+"You Registered Successfully.";
                    mail.Mailerr.send(Email, subject, MessageBody);
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('Successfully SignUp')");
                         out.println("window.location.href='login.jsp'");
                         out.println("</script>");
                    }
                    else{
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('You are not signUp')");
                         out.println("window.location.href='signup.jsp'");
                         out.println("</script>");
                    }
                }
                
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
