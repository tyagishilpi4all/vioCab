/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import connect.connect_db;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shilpi
 */
public class EditSocialLink extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String Facebook = request.getParameter("fb");
            String Google = request.getParameter("g");
            String Instagram = request.getParameter("insta");
            String YouTube = request.getParameter("youtube");
            System.out.println(Facebook+" "+Google+" "+Instagram+" "+YouTube);
            try{
                Connection con = new connect_db().getConnection();
                PreparedStatement ps = con.prepareStatement("update sociallink set facebook=? G+=?,instagram=?, youtube=? where id=?");
                ps.setString(1, Facebook);
                ps.setString(2, Google);
                ps.setString(3, Instagram);
                ps.setString(4, YouTube);
                int i =ps.executeUpdate();
                if(i>0){
                     out.println("<script type=\"text/javascript\">");
                       out.println("alert('Successfully Social link updated')");
                       out.println("window.location.href='admin/viewSocialLink.jsp'");
                       out.println("</script>");
                }
                else{
                     out.println("<script type=\"text/javascript\">");
                       out.println("alert('Social Link Updated')");
                       out.println("window.location.href='admin/viewSocialLink.jsp'");
                       out.println("</script>");
                }
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
